<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchases_detail extends Model
{
    //
}
