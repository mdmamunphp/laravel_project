<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sellinvoice extends Model
{
    //
}
