<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sipping extends Model
{
    //
    protected $table = 'shippings';
}
